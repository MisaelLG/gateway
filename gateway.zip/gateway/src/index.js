const express = require("express");
const initDB = require("./database.js");
const morgan = require("morgan");
const app = express();

// settings
app.set("port", process.env.PORT || 3000);

// Database
initDB();
// middlewares
app.use(morgan("dev"));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// routes
app.use(require("./routes"));
app.use("/api/zelle", require("./routes/zelle"));
app.use("/api/movil", require("./routes/movil"));
app.use("/api/cash", require("./routes/cash"));

// starting the server
app.listen(app.get("port"), () => {
  console.log(`Server on port ${app.get("port")}`);
});
