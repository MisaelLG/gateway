// Endpoints for external data
const { Router } = require("express");
const router = new Router();
const model = require("../models/movil");

router.post("/", async (req, res) => {
  const { metodo, monto, code, phone, reference } = req.body;

  const newPayments = new model({ metodo, monto, code, phone, reference });

  const paymentsSave = await newPayments.save();

  res.status(201).json(paymentsSave);
  console.log(paymentsSave);
});
router.get("/", async (req, res) => {
  const payments = await model.find();

  console.log(payments);
  res.json(payments);
});

module.exports = router;
