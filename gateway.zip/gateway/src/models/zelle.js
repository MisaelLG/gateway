const mongoose = require("mongoose");

const ZelleScheme = new mongoose.Schema({
  metodo: {
    type: String,
  },
  monto: {
    type: String,
  },
  code: {
    type: String,
  },
  creado_en: Date,
  actualizado_en: { type: Date, default: Date.now },
});

module.exports = mongoose.model("zelle", ZelleScheme);
