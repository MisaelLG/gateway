const mongoose = require("mongoose");

const MovilScheme = new mongoose.Schema({
  metodo: {
    type: String,
  },
  monto: {
    type: String,
  },
  code: {
    type: String,
  },
  phone: Number,
  reference: Number,
  creado_en: Date,
  actualizado_en: { type: Date, default: Date.now },
});

module.exports = mongoose.model("movil", MovilScheme);
