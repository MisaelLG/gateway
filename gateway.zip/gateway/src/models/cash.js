const mongoose = require("mongoose");

const CashScheme = new mongoose.Schema({
  metodo: {
    type: String,
  },
  monto: {
    type: String,
  },
  restante: {
    type: String,
  },
  phone: Number,
  creado_en: Date,
  actualizado_en: { type: Date, default: Date.now },
});

module.exports = mongoose.model("cash", CashScheme);
