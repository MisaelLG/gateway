const mongoose = require("mongoose");

const DB_URI = `mongodb://localhost:27017/payments`;

module.exports = () => {
  const connect = () => {
    mongoose.connect(
      DB_URI,
      {
        keepAlive: true,
        useNewUrlParser: true,
        useUnifiedTopology: true,
      },
      (err) => {
        if (err) {
          console.log("Error de conexion a la base de datos");
        } else {
          console.log("Conexion a la base de datos corecta");
        }
      }
    );
  };
  connect();
};
